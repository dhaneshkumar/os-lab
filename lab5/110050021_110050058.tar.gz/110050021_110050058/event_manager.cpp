#include "event_manager.h"
using namespace std;



EventManager::EventManager()
{
	clocktime = 0;
	 	for(int i=0;i<process_list.size();i++)
	 	{
	 		Event  e;
	 		e.startTime = process_list[i].admission;
	 		e.type = 1;
	 		e.newProcess = process_list[i];

	 		eventList.push_back(e);
	 	}

	 	sort (eventList.begin(), eventList.end());	
	 }



void EventManager::addEvent(Event  e)
{
	Event  e1;
	e1.startTime = e.startTime;
	e1.type = e.type;
	e1.newProcess = e.newProcess;
	eventList.push_back(e1);
	sort (eventList.begin(), eventList.end());
}

void EventManager::removeEvent(Event  e)
{
	eventList.erase(remove(eventList.begin(), eventList.end(), e), eventList.end());
	// for(int j=0; j<eventList.size();j++)
	// {
	// 	if(eventList[j]==e)
	// 	{
	// 		eventList.erase (eventList.begin()+j);
	// 	}
	// }
	sort (eventList.begin(), eventList.end());
	cout<<"event removed"<<endl;
}



void EventManager::admit(process p)
{
	//cout<<"process adding"<<endl;
		p.state="ready";
		sd->addProcess(p);

		cout<<"process added"<<endl;
		//sd.schedule();
}


void EventManager::ioStart(process p){

	cout<<"iostarted"<<endl;
	p.state="blocked";
	eventTable.pop();

	cout<<"process id : "<<p.p_id<<" start io operation"<<endl;

	Event  e;
	e.startTime = clocktime + p.phases.front().io_time ;
	e.type = 3;
	e.newProcess = p;

	addEvent(e);

	//sd.schedule();
}


void EventManager::ioComplete(process p){

	if(p.phases.front().iterations==1)
	{
		p.phases.erase(p.phases.begin());
		cout<<"process id "<<p.p_id<<"finished"<<endl;
	}
	else
	{
		cout<<"process id "<<p.p_id<<"completed phase"<<p.phases.front().iterations<<endl;
		p.phases.front().iterations--;

	

	Event  e;
	e.startTime = clocktime + p.phases.front().io_time ;
	e.type = 1;
	e.newProcess = p;

	addEvent(e);
	}
	//sd.schedule();
}

void EventManager::run()
{
	cout<<"program start :" <<endl;

	int dmd=0;
	while(!eventList.empty())
	{

		
		Event e = eventList.front();
		clocktime =e.startTime;

		while(clocktime == e.startTime)
		{
			cout<<"event:"<<dmd++<<" type : "<<e.type<<"   time : "<<clocktime<<endl;
			if(e.type==1)
			{
				cout<<" event type 1"<<endl;
				admit(e.newProcess);
			}
			else if(e.type==2)
			{
				cout<<" event type 2"<<endl;
				ioStart(e.newProcess);
			}
			else if(e.type==3)
			{
				cout<<" event type 3"<<endl;
				ioComplete(e.newProcess);
			}

			eventList.erase(eventList.begin());
			e = eventList.front();
		}

		cout<<"start scheduling "<<endl;
		sd->schedule();

	}
}


